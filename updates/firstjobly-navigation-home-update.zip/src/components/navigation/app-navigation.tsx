import { useEffect, useState } from "react";
import { Animated, Dimensions, Keyboard, Modal, Platform, Pressable, ScrollView, StyleSheet, View, useWindowDimensions } from "react-native";
import type { ComponentProps } from "react";
import { Tabs } from "expo-router";
import { Bookmark, BriefcaseBusiness, Check, ChevronRight, ClipboardList, GraduationCap, Home, Menu, User, Wrench, X } from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { AppText as Text } from "../ui/primitives";
import { Colors, Fonts, Layout, Radius, Space } from "../../constants/theme";
import { useReducedMotion } from "../../hooks/use-reduced-motion";

type BottomTabBarProps = Parameters<NonNullable<ComponentProps<typeof Tabs>["tabBar"]>>[0];

const destinations = [
  { name: "index", label: "Home", icon: Home, group: "Your next move", description: "Your starting point" },
  { name: "jobs", label: "Find jobs", icon: BriefcaseBusiness, group: "Your next move", description: "Search and explore opportunities" },
  { name: "saved", label: "Saved jobs", icon: Bookmark, group: "Your next move", description: "Return to your shortlist" },
  { name: "applications", label: "Applications", icon: ClipboardList, group: "Your next move", description: "Drafts and application progress" },
  { name: "tools", label: "Career tools", icon: Wrench, group: "Your career", description: "CV maker and Z83 form" },
  { name: "graduateroom", label: "Graduate Room", icon: GraduationCap, group: "Your career", description: "Conversations with your community" },
  { name: "profile", label: "Profile", icon: User, group: "Your career", description: "Your details and preferences" },
];

/** Uses the tab navigator's routes and events so tab state and back behavior survive. */
export function AppNavigation({ state, navigation }: BottomTabBarProps) {
  const { width, height } = useWindowDimensions();
  const desktop = width >= Layout.desktop;
  const insets = useSafeAreaInsets();
  const reduced = useReducedMotion();
  const [open, setOpen] = useState(false);
  const [keyboard, setKeyboard] = useState(false);
  const [progress] = useState(() => new Animated.Value(0));
  const active = state.routes[state.index]?.name;
  const current = destinations.find((item) => item.name === active);
  const visible = destinations.filter((item) => state.routes.some((route) => route.name === item.name));

  function close() { setOpen(false); }
  function select(name: string) {
    const route = state.routes.find((item) => item.name === name);
    if (!route) return;
    const event = navigation.emit({ type: "tabPress", target: route.key, canPreventDefault: true });
    close();
    if (!event.defaultPrevented) navigation.navigate(route.name, route.params);
  }

  const [lastActive, setLastActive] = useState(active);
  if (lastActive !== active) { setLastActive(active); setOpen(false); }
  useEffect(() => {
    const show = Keyboard.addListener("keyboardDidShow", () => { setKeyboard(true); setOpen(false); });
    const hide = Keyboard.addListener("keyboardDidHide", () => setKeyboard(false));
    const resize = Dimensions.addEventListener("change", () => setOpen(false));
    return () => { show.remove(); hide.remove(); resize.remove(); };
  }, []);
  useEffect(() => {
    if (!open) { progress.setValue(0); return; }
    const animation = Animated.timing(progress, { toValue: 1, duration: reduced ? 0 : 160, useNativeDriver: Platform.OS !== "web" });
    animation.start();
    return () => animation.stop();
  }, [open, reduced, progress]);

  // React Native's Modal supplies the native accessibility boundary. Web also needs
  // explicit initial focus, a keyboard loop, Escape, and restoration to the launcher.
  useEffect(() => {
    if (!open || Platform.OS !== "web") return;
    const previous = document.activeElement as HTMLElement | null;
    const controls = () => Array.from(document.getElementById("navigation-sheet")?.querySelectorAll<HTMLElement>('button, [role="button"], [tabindex="0"]') ?? []).filter((node) => node.getAttribute("aria-disabled") !== "true");
    const timer = setTimeout(() => controls()[0]?.focus(), 50);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); setOpen(false); }
      if (event.key !== "Tab") return;
      const items = controls();
      const first = items[0], last = items[items.length - 1];
      if (event.shiftKey && (document.activeElement === first || !items.includes(document.activeElement as HTMLElement))) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !items.includes(document.activeElement as HTMLElement))) { event.preventDefault(); first?.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      clearTimeout(timer);
      document.removeEventListener("keydown", onKey);
      setTimeout(() => { if (previous?.isConnected) previous.focus(); }, 0);
    };
  }, [open]);

  useEffect(() => {
    if (!desktop || Platform.OS !== "web") return;
    const bar = document.getElementById("desktop-navigation");
    const onKey = (event: KeyboardEvent) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      const tabs = Array.from(bar?.querySelectorAll<HTMLElement>('[role="tab"]') ?? []);
      const index = tabs.indexOf(document.activeElement as HTMLElement);
      if (index < 0 || !tabs.length) return;
      event.preventDefault();
      const next = event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
      tabs[next]?.focus();
    };
    bar?.addEventListener("keydown", onKey);
    return () => bar?.removeEventListener("keydown", onKey);
  }, [desktop]);

  function destination(item: typeof destinations[number], compact: boolean) {
    const selected = active === item.name;
    const Glyph = item.icon;
    return (
      <Pressable key={item.name} accessibilityRole={compact ? "tab" : "button"} accessibilityLabel={item.label} accessibilityState={{ selected }} aria-selected={selected} tabIndex={compact && !selected ? -1 : 0}
        onPress={() => select(item.name)}
        onLongPress={() => { const route = state.routes.find((r) => r.name === item.name); if (route) navigation.emit({ type: "tabLongPress", target: route.key }); }}
        style={({ pressed, hovered }) => [compact ? styles.desktopItem : styles.destination, selected && styles.selected, (pressed || hovered) && styles.feedback]}>
        <View aria-hidden={true} style={[styles.icon, selected && styles.activeIcon]}><Glyph size={20} color={selected ? Colors.primary : Colors.muted} /></View>
        <View style={styles.copy}>
          <Text style={[styles.label, selected && styles.activeLabel]}>{item.label}</Text>
          {!compact && <Text style={styles.description}>{item.description}</Text>}
        </View>
        {!compact && (selected ? <Check aria-hidden={true} size={18} color={Colors.primary} /> : <ChevronRight aria-hidden={true} size={17} color={Colors.muted} />)}
      </Pressable>
    );
  }

  if (desktop) return <View nativeID="desktop-navigation" accessibilityRole="tablist" accessibilityLabel="Main navigation" style={[styles.desktop, { paddingTop: Math.max(insets.top, Space.md) }]}>{visible.map((item) => destination(item, true))}</View>;
  if (keyboard) return null;
  return (
    <>
      <View style={[styles.bar, { paddingBottom: Math.max(insets.bottom, Space.sm) }]}>
        <View style={styles.dock}>
          <Pressable accessibilityRole="button" accessibilityLabel="Home" accessibilityState={{ selected: active === "index" }} aria-current={active === "index" ? "page" : undefined} onPress={() => select("index")}
            style={({ pressed, hovered }) => [styles.home, active === "index" && styles.selected, (pressed || hovered) && styles.feedback]}>
            <Home aria-hidden={true} size={21} color={active === "index" ? Colors.primary : Colors.muted} />
            <Text style={[styles.label, active === "index" && styles.activeLabel]}>Home</Text>
          </Pressable>
          <View style={styles.divider} />
          <Pressable accessibilityRole="button" accessibilityLabel={active === "index" ? "Open navigation menu" : `Open navigation menu, current page: ${current?.label ?? active}`} accessibilityState={{ expanded: open }} aria-expanded={open} {...(Platform.OS === "web" ? { "aria-controls": "navigation-sheet", "aria-haspopup": "dialog" as const } : {})}
            onPress={() => setOpen(true)} style={({ pressed, hovered }) => [styles.launcher, (pressed || hovered) && styles.feedback]}>
            <View style={[styles.launcherIcon, active !== "index" && styles.activeIcon]}><Menu aria-hidden={true} size={22} color={Colors.primary} /></View>
            <Text numberOfLines={1} style={styles.label}>{active === "index" ? "Menu" : current?.label ?? "Menu"}</Text>
          </Pressable>
        </View>
      </View>
      <Modal visible={open} transparent animationType="none" onRequestClose={close} statusBarTranslucent>
        <View style={styles.modal}>
          <Pressable accessible={false} importantForAccessibility="no" style={StyleSheet.absoluteFill} onPress={close} />
          <Animated.View nativeID="navigation-sheet" {...(Platform.OS === "web" ? { role: "dialog" as const, "aria-modal": true } : {})} accessibilityViewIsModal accessibilityLabel="Navigation menu" style={[styles.sheet, { maxHeight: height - insets.top - Space.xl, paddingBottom: Math.max(insets.bottom, Space.lg), opacity: progress, transform: [{ translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }] }]}>
            <View style={styles.sheetHeader}>
              <View style={styles.copy}><Text accessibilityRole="header" style={styles.title}>Where to next?</Text><Text style={styles.description}>Everything you need, in one place.</Text></View>
              <Pressable accessibilityRole="button" accessibilityLabel="Close navigation menu" onPress={close} style={({ pressed, hovered }) => [styles.close, (pressed || hovered) && styles.feedback]}><X aria-hidden={true} size={22} color={Colors.foreground} /></Pressable>
            </View>
            <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.sheetContent}>
              {["Your next move", "Your career"].map((group) => <View key={group} style={styles.group}>
                <Text accessibilityRole="header" style={styles.groupTitle}>{group}</Text>
                {visible.filter((item) => item.group === group && item.name !== "index").map((item) => destination(item, false))}
              </View>)}
              {visible.filter((item) => item.name === "index").map((item) => destination(item, false))}
            </ScrollView>
          </Animated.View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  bar: { backgroundColor: Colors.background, paddingTop: Space.sm, paddingHorizontal: Space.lg, alignItems: "center", borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.border },
  dock: { flexDirection: "row", alignItems: "center", padding: 5, width: "100%", maxWidth: 300, backgroundColor: Colors.surface, borderRadius: Radius.pill, borderWidth: 1, borderColor: Colors.border },
  home: { minHeight: 48, flex: 1, flexDirection: "row", gap: Space.sm, alignItems: "center", justifyContent: "center", borderRadius: Radius.pill, paddingHorizontal: Space.md },
  launcher: { minHeight: 48, flex: 1, flexDirection: "row", gap: Space.sm, alignItems: "center", paddingHorizontal: Space.sm, borderRadius: Radius.pill },
  launcherIcon: { width: 36, height: 36, borderRadius: Radius.pill, backgroundColor: Colors.secondary, alignItems: "center", justifyContent: "center" },
  divider: { width: 1, height: 22, backgroundColor: Colors.border, marginHorizontal: Space.xs },
  desktop: { padding: Space.md, gap: Space.xs, flexDirection: "row", borderBottomWidth: 1, borderBottomColor: Colors.border, backgroundColor: Colors.surface },
  desktopItem: { minHeight: 48, flex: 1, flexDirection: "row", gap: Space.xs, alignItems: "center", paddingHorizontal: Space.sm, borderRadius: Radius.sm },
  icon: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: Radius.sm },
  copy: { flex: 1, minWidth: 0 },
  label: { fontSize: 12, fontFamily: Fonts.semibold, flexShrink: 1 },
  activeLabel: { color: Colors.primary },
  selected: { backgroundColor: Colors.primarySoft },
  activeIcon: { backgroundColor: Colors.primarySoft },
  feedback: { backgroundColor: Colors.secondary },
  modal: { flex: 1, justifyContent: "flex-end", alignItems: "center", backgroundColor: "rgba(20,28,24,0.36)" },
  sheet: { width: "100%", maxWidth: 560, backgroundColor: Colors.surface, borderTopLeftRadius: Radius.lg, borderTopRightRadius: Radius.lg, overflow: "hidden", flexShrink: 1 },
  sheetHeader: { flexDirection: "row", alignItems: "center", gap: Space.md, padding: Space.xl, paddingBottom: Space.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.border },
  title: { fontFamily: Fonts.bold, fontSize: 20, lineHeight: 28 },
  description: { fontSize: 12, lineHeight: 18, color: Colors.muted, marginTop: 3 },
  close: { minWidth: 44, minHeight: 44, alignItems: "center", justifyContent: "center", borderRadius: Radius.pill, backgroundColor: Colors.secondary },
  sheetContent: { padding: Space.lg, gap: Space.lg },
  group: { gap: Space.xs },
  groupTitle: { color: Colors.muted, fontSize: 12, fontFamily: Fonts.semibold, paddingHorizontal: Space.sm, marginBottom: Space.xs },
  destination: { minHeight: 64, flexDirection: "row", alignItems: "center", gap: Space.md, borderRadius: Radius.sm, paddingHorizontal: Space.sm, paddingVertical: Space.sm },
});
