import {
  AppText as Text,
  AppTouchableOpacity as TouchableOpacity,
} from "../../components/ui/primitives";
import { Colors, Fonts, Radius, Layout } from "../../constants/theme";
import { useEffect, useState } from "react";
import {
  useWindowDimensions,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Icon as Ionicons } from "../../components/ui/icon";
import { router } from "expo-router";

import { getJobs } from "../../lib/job-api";
import type { Job } from "../../lib/jobs";
import { useScreenBottomPadding } from "../../hooks/use-screen-bottom-padding";
import { useHomeSummary } from "../../hooks/use-home-summary";
import { IdentityImage } from "../../components/ui/identity-image";
import { useAuth } from "../../hooks/use-auth";
import { JobMetadata } from "../../components/ui/job-metadata";
import { categoryLabel } from "../../lib/job-filters";
import {
  EmptyState,
  InlineErrorState,
  SkeletonJobCard,
} from "../../components/ui/app-ui";
import { useEarlyJobInterstitial } from "../../ads/useJobInterstitial";

const categories = [
  {
    name: "Learnerships",
    subtitle: "Start learning while gaining work experience",
    icon: "school-outline",
    params: { category: "learnership" },
  },
  {
    name: "Internships",
    subtitle: "Build practical experience in your field",
    icon: "business-outline",
    params: { category: "internship" },
  },
  {
    name: "Graduate roles",
    subtitle: "Opportunities designed for new graduates",
    icon: "ribbon-outline",
    params: { category: "graduate_programme" },
  },
  {
    name: "Government",
    subtitle: "Explore public-sector opportunities",
    icon: "flag-outline",
    params: { category: "government" },
  },
];

export default function HomeScreen() {
  const wide = useWindowDimensions().width >= 760;
  const { user, userId, loading: authLoading } = useAuth();
  const { summary, loading: summaryLoading, retry: retrySummary } = useHomeSummary(userId);
  const { openJobWithEarlyInterstitial } = useEarlyJobInterstitial();
  const firstName = String(summary?.profile?.first_name || user?.user_metadata?.full_name || user?.user_metadata?.name || "").trim().split(/\s+/)[0];
  const avatar = typeof user?.user_metadata?.avatar_url === "string" ? user.user_metadata.avatar_url : null;
  const draft = summary?.applications?.find((item) => item.is_draft && item.jobs);
  const submitted = summary?.applications?.filter((item) => !item.is_draft).length ?? 0;
  const province = summary?.profile?.preferred_province;

  const hour = new Date().getHours();
  const dayGreeting =
    hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  const greetingLabel = firstName
    ? `${dayGreeting}, ${firstName}`
    : "Find your next opportunity";

  const bottomContentPadding = useScreenBottomPadding(true);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);

  const [reload, setReload] = useState(0);
  function loadJobs() {
    setLoading(true);
    setError(null);
    setReload((value) => value + 1);
  }

  useEffect(() => {
    let active = true;
    getJobs(0)
      .then((data) => {
        if (active) setJobs(data.slice(0, 6));
      })
      .catch(() => {
        if (active)
          setError("We couldn’t load opportunities. Please try again.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [reload]);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.content,
          { paddingBottom: bottomContentPadding },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={styles.brandBlock}>
            <Text style={styles.logo}>
              First<Text style={styles.logoDark}>Jobly</Text>
            </Text>
            <Text style={styles.tagline}>Your next step starts here.</Text>
          </View>

          <TouchableOpacity
            style={styles.notification}
            accessibilityLabel="Open profile"
            onPress={() => router.push("/profile")}
          >
            <IdentityImage uri={avatar} name={firstName || ""} size={40} portrait />
          </TouchableOpacity>
        </View>

        <View style={styles.hero}>
          <Text style={styles.heroEyebrow}>YOUR HOME</Text>
          <Text style={styles.heroTitle}>{greetingLabel}</Text>
          <Text style={styles.heroText}>
            {province ? `Explore opportunities in ${province}, or search somewhere new.` : "A new role. A first step. Find an opportunity that fits."}
          </Text>

          <TouchableOpacity
            accessibilityLabel="Search jobs or companies"
            style={styles.search}
            activeOpacity={0.82}
            onPress={() => router.push("/jobs")}
          >
            <Ionicons name="search" size={20} color={Colors.muted} />
            <Text style={styles.searchText}>Search jobs or companies</Text>
            <Ionicons
              name="arrow-forward"
              size={18}
              color={Colors.foreground}
            />
          </TouchableOpacity>
        </View>

        {authLoading || (userId && summaryLoading && !summary) ? (
          <View style={styles.personalSection} accessibilityLabel="Loading your overview"><SkeletonJobCard /></View>
        ) : !userId ? (
          <TouchableOpacity style={styles.startRow} onPress={() => router.push("/auth")}>
            <View style={styles.categoryIcon}><Ionicons name="bookmark-outline" size={20} color={Colors.primary} /></View>
            <View style={styles.categoryCopy}><Text style={styles.categoryText}>Keep your next move close</Text><Text style={styles.categorySubtitle}>Sign in to save jobs and track applications.</Text></View>
            <Ionicons name="chevron-forward" size={18} color={Colors.muted} />
          </TouchableOpacity>
        ) : (
          <View style={styles.personalSection}>
            {summary?.failed && <InlineErrorState message="Some of your overview couldn’t load." onRetry={retrySummary} />}
            {draft?.jobs ? (
              <TouchableOpacity style={styles.nextStep} onPress={() => router.push({ pathname: "/jobs/[id]", params: { id: draft.jobs!.id } })}>
                <Text style={styles.heroEyebrow}>PICK UP WHERE YOU LEFT OFF</Text>
                <Text style={styles.nextTitle}>{draft.jobs.title}</Text>
                <Text style={styles.sectionSubtitle}>{draft.jobs.company_name} · Draft application</Text>
                <View style={styles.actionLine}><Text style={styles.viewAll}>Continue application</Text><Ionicons name="arrow-forward" size={18} color={Colors.primary} /></View>
              </TouchableOpacity>
            ) : summary?.completion !== null && summary?.completion !== undefined && summary.completion < 100 ? (
              <TouchableOpacity style={styles.nextStep} accessibilityLabel={`Profile ${summary.completion}% complete. Complete your profile`} onPress={() => router.push("/profile")}>
                <View style={styles.progressHeader}><Text style={styles.categoryText}>{summary.completion === 0 ? "Make this space yours" : "Your profile, one step closer"}</Text><Text style={styles.viewAll}>{summary.completion}%</Text></View>
                <Text style={styles.sectionSubtitle}>Add your details and documents for Easy Apply.</Text>
                <View accessibilityRole="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={summary.completion} accessibilityLabel="Profile completion" accessibilityValue={{ min: 0, max: 100, now: summary.completion }} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${summary.completion}%` }]} /></View>
                <View style={styles.actionLine}><Text style={styles.viewAll}>Complete your profile</Text><Ionicons name="arrow-forward" size={18} color={Colors.primary} /></View>
              </TouchableOpacity>
            ) : null}
            <View style={[styles.shortcutRow, !wide && { flexDirection: "column" }]}>
              <TouchableOpacity style={styles.shortcut} onPress={() => router.push("/saved")}>
                <Ionicons name="bookmark-outline" size={20} color={Colors.primary} />
                <View style={styles.categoryCopy}><Text style={styles.categoryText}>Saved jobs</Text><Text style={styles.categorySubtitle}>{summary?.savedCount ? `${summary.savedCount} saved for another look` : "Your shortlist, ready when you are"}</Text></View>
                <Ionicons name="chevron-forward" size={18} color={Colors.muted} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.shortcut} onPress={() => router.push("/applications")}>
                <Ionicons name="reader-outline" size={20} color={Colors.primary} />
                <View style={styles.categoryCopy}><Text style={styles.categoryText}>Applications</Text><Text style={styles.categorySubtitle}>{submitted ? `${submitted} submitted · View progress` : "Drafts and progress in one place"}</Text></View>
                <Ionicons name="chevron-forward" size={18} color={Colors.muted} />
              </TouchableOpacity>
            </View>
            {!!province && <TouchableOpacity style={styles.preferenceRow} onPress={() => router.push({ pathname: "/jobs", params: { province } })}>
              <Ionicons name="location-outline" size={18} color={Colors.primary} /><Text style={styles.preferenceLabel}>Explore jobs in {province}</Text><Ionicons name="arrow-forward" size={18} color={Colors.primary} />
            </TouchableOpacity>}
          </View>
        )}

        <View style={styles.sectionHeaderJobs}>
          <View style={styles.sectionHeadingCopy}>
            <Text style={styles.sectionTitle}>Latest opportunities</Text>
            <Text style={styles.sectionSubtitle}>
              Recently posted jobs to explore
            </Text>
          </View>

          <TouchableOpacity
            style={styles.seeAllButton}
            onPress={() => router.push("/jobs")}
          >
            <Text style={styles.viewAll}>See all</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <View style={styles.jobsList}>
            <SkeletonJobCard />
            <SkeletonJobCard />
            <SkeletonJobCard />
          </View>
        ) : error ? (
          <InlineErrorState message={error} onRetry={loadJobs} />
        ) : jobs.length === 0 ? (
          <EmptyState
            title="No opportunities yet"
            message="Check back soon or explore job search."
            actionLabel="Search jobs"
            onAction={() => router.push("/jobs")}
          />
        ) : (
          <View style={styles.jobsList}>
            {jobs.map((job) => (
              <TouchableOpacity
                key={job.id}
                style={styles.jobCard}
                activeOpacity={0.78}
                onPress={() =>
                  void openJobWithEarlyInterstitial(() =>
                    router.push({
                      pathname: "/jobs/[id]",
                      params: { id: job.id },
                    }),
                  )
                }
              >
                <IdentityImage uri={job.company_logo_url} name={job.company_name} size={44} />

                <View style={styles.jobContent}>
                  <Text style={styles.jobTitle}>{job.title}</Text>

                  <Text style={styles.company}>{job.company_name}</Text>

                  <View style={styles.jobMeta}>
                    <Ionicons
                      name="location-outline"
                      size={14}
                      color={Colors.muted}
                    />
                    <Text style={styles.metaText} numberOfLines={1}>
                      {job.city ? `${job.city}, ${job.province}` : job.province}
                    </Text>
                  </View>

                  <JobMetadata job={job} />
                  <View style={styles.badges}>
                    <View style={styles.badge}>
                      <Text style={styles.badgeText}>
                        {categoryLabel(job.category)}
                      </Text>
                    </View>

                    {job.is_urgent && (
                      <View style={styles.urgentBadge}>
                        <Text style={styles.urgentText}>Urgent</Text>
                      </View>
                    )}
                  </View>
                </View>

                <Ionicons
                  name="chevron-forward"
                  size={20}
                  color={Colors.mutedSubtle}
                  style={styles.jobChevron}
                />
              </TouchableOpacity>
            ))}
          </View>
        )}
        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>Find your fit</Text>
            <Text style={styles.sectionSubtitle}>Choose a starting point</Text>
          </View>
        </View>

        <View
          style={[
            styles.categoryList,
            wide && { flexDirection: "row", flexWrap: "wrap" },
          ]}
        >
          {categories.map((category) => (
            <TouchableOpacity
              key={category.name}
              style={[styles.category, wide && { width: "48%", flexGrow: 1 }]}
              activeOpacity={0.78}
              onPress={() =>
                router.push({
                  pathname: "/jobs",
                  params: category.params,
                })
              }
            >
              <View style={styles.categoryIcon}>
                <Ionicons
                  name={category.icon as any}
                  size={21}
                  color={Colors.primary}
                />
              </View>

              <View style={styles.categoryCopy}>
                <Text style={styles.categoryText}>{category.name}</Text>
                <Text style={styles.categorySubtitle}>{category.subtitle}</Text>
              </View>

              <Ionicons
                name="chevron-forward"
                size={20}
                color={Colors.mutedSubtle}
              />
            </TouchableOpacity>
          ))}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  personalSection: { marginHorizontal: 16, marginTop: 16, gap: 12 },
  startRow: { marginHorizontal: 16, marginTop: 16, padding: 14, backgroundColor: Colors.surface, borderRadius: Radius.sm, flexDirection: "row", alignItems: "center", gap: 4 },
  nextStep: { padding: 18, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surface },
  nextTitle: { fontSize: 18, lineHeight: 25, fontFamily: Fonts.semibold, marginTop: 10 },
  actionLine: { marginTop: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", minHeight: 28 },
  progressHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  progressTrack: { height: 4, backgroundColor: Colors.secondary, borderRadius: Radius.pill, marginTop: 16, overflow: "hidden" },
  progressFill: { height: "100%", backgroundColor: Colors.primary, borderRadius: Radius.pill },
  shortcutRow: { flexDirection: "row", gap: 10 },
  shortcut: { flex: 1, minHeight: 76, flexDirection: "row", gap: 12, padding: 14, backgroundColor: Colors.surface, borderRadius: Radius.sm, alignItems: "center" },
  preferenceRow: { minHeight: 48, flexDirection: "row", gap: 8, alignItems: "center", paddingHorizontal: 4 },
  preferenceLabel: { flex: 1, color: Colors.primary, fontSize: 13, fontFamily: Fonts.medium },
  safe: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  container: {
    flex: 1,
  },
  content: {
    paddingTop: 4,
    width: "100%",
    maxWidth: Layout.reading,
    alignSelf: "center",
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 6,
    paddingBottom: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  brandBlock: {
    flex: 1,
    paddingRight: 12,
  },
  logo: {
    color: Colors.primary,
    fontSize: 26,
    lineHeight: 32,
    fontFamily: Fonts.bold,
    fontWeight: "700",
  },
  logoDark: {
    color: Colors.foreground,
  },
  tagline: {
    marginTop: 3,
    color: Colors.muted,
    fontSize: 12,
    fontFamily: Fonts.medium,
  },
  notification: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  hero: {
    marginHorizontal: 16,
    backgroundColor: Colors.secondary,
    borderRadius: Radius.md,
    padding: 20,
  },
  heroEyebrow: {
    color: Colors.primary,
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 0.9,
    fontFamily: Fonts.bold,
    fontWeight: "700",
  },
  heroTitle: {
    color: Colors.foreground,
    fontSize: 26,
    lineHeight: 34,
    marginTop: 9,
    letterSpacing: -0.5,
    fontFamily: Fonts.bold,
    fontWeight: "700",
  },
  heroText: {
    color: Colors.muted,
    marginTop: 10,
    lineHeight: 21,
    fontSize: 14,
    maxWidth: 560,
    fontFamily: Fonts.regular,
  },
  search: {
    marginTop: 20,
    minHeight: 54,
    borderRadius: Radius.sm,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.input,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  searchText: {
    flex: 1,
    fontSize: 14,
    color: Colors.muted,
    fontFamily: Fonts.medium,
  },
  sectionHeader: {
    marginTop: 30,
    marginBottom: 12,
    paddingHorizontal: 16,
  },
  sectionHeaderJobs: {
    marginTop: 30,
    marginBottom: 12,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  sectionHeadingCopy: {
    flex: 1,
    paddingRight: 12,
  },
  sectionTitle: {
    fontSize: 18,
    lineHeight: 25,
    fontFamily: Fonts.bold,
    fontWeight: "700",
    color: Colors.foreground,
  },
  sectionSubtitle: {
    marginTop: 3,
    color: Colors.muted,
    fontSize: 12,
    lineHeight: 17,
    fontFamily: Fonts.regular,
  },
  seeAllButton: {
    minHeight: 44,
    justifyContent: "center",
    paddingHorizontal: 4,
  },
  viewAll: {
    color: Colors.primary,
    fontFamily: Fonts.bold,
    fontWeight: "700",
    fontSize: 13,
  },
  categoryList: {
    paddingHorizontal: 16,
    gap: 10,
  },
  category: {
    minHeight: 70,
    padding: 12,
    backgroundColor: Colors.surface,
    borderRadius: Radius.sm,
    borderBottomWidth: 1,
    borderColor: Colors.border,
    flexDirection: "row",
    alignItems: "center",
  },
  categoryIcon: {
    width: 42,
    height: 42,
    borderRadius: Radius.md,
    backgroundColor: Colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  categoryCopy: {
    flex: 1,
    minWidth: 0,
  },
  categoryText: {
    color: Colors.foreground,
    fontFamily: Fonts.bold,
    fontWeight: "700",
    fontSize: 14,
    lineHeight: 19,
  },
  categorySubtitle: {
    marginTop: 2,
    color: Colors.muted,
    fontFamily: Fonts.regular,
    fontSize: 11,
    lineHeight: 16,
  },
  jobsList: {
    gap: 12,
  },
  jobCard: {
    marginHorizontal: 16,
    minHeight: 124,
    backgroundColor: Colors.surface,
    borderRadius: Radius.sm,
    padding: 16,
    flexDirection: "row",
    alignItems: "flex-start",
    borderWidth: 1,
    borderColor: Colors.border,
    shadowColor: Colors.foreground,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0,
    shadowRadius: 12,
    elevation: 0,
  },
  jobContent: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
    minWidth: 0,
  },
  jobTitle: {
    color: Colors.foreground,
    fontSize: 15,
    lineHeight: 21,
    fontFamily: Fonts.bold,
    fontWeight: "700",
  },
  company: {
    color: Colors.muted,
    marginTop: 3,
    fontSize: 13,
    lineHeight: 18,
    fontFamily: Fonts.regular,
  },
  jobMeta: {
    marginTop: 7,
    flexDirection: "row",
    alignItems: "center",
  },
  metaText: {
    flex: 1,
    color: Colors.muted,
    fontSize: 11,
    lineHeight: 16,
    marginLeft: 4,
    fontFamily: Fonts.regular,
  },
  badges: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 7,
    marginTop: 8,
  },
  badge: {
    backgroundColor: Colors.secondary,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 7,
  },
  badgeText: {
    color: Colors.muted,
    fontSize: 11,
    fontFamily: Fonts.semibold,
    fontWeight: "600",
  },
  urgentBadge: {
    backgroundColor: Colors.primarySoft,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 7,
  },
  urgentText: {
    color: Colors.primary,
    fontSize: 11,
    fontFamily: Fonts.bold,
    fontWeight: "700",
  },
  jobChevron: {
    marginTop: 14,
  },
});
