# FirstJobly navigation and Home update

This update applies to the uploaded `firstjobly-source.zip`. The connected GitHub main branch contains a different version, so this is an overlay for the uploaded local project, not a replacement for that branch.

## Install on Windows

1. Stop Expo with Ctrl+C and back up your project (or commit local changes).
2. Extract the update ZIP directly into `C:\Users\asus\firstjobly-native`, replacing the matching files. The ZIP contains only changed files and this guide. It does not contain `.env`, credentials, dependencies, native build products, or a replacement database.
3. From that project folder, run:

```powershell
npm run test:navigation
npx expo start --clear
```

No new runtime dependencies were added. Keep your existing `.env.local` and Supabase values.

## Changes

- Replaced seven crowded mobile tabs with a compact Home/Menu dock. Menu opens a scrollable, grouped bottom sheet with labeled destinations; Home remains immediately accessible. Seven destinations are too many for a readable radial arrangement.
- Retained the tab navigator's actual routes, tab events, route params, long-press events, and history. Desktop retains all seven destinations, including arrow-key focus navigation.
- Added safe-area spacing, native keyboard hiding, Android modal back handling, touch feedback, accessible expanded and selected states, a visible close button, web focus trapping/restoration, Escape handling, and reduced-motion support.
- Default sign-in and sign-up destination is Home. Contextual sign-in retains validated job, saved-job, application, profile, community, CV-maker, and Z83 return destinations. Explicit launch links are not overwritten by a global redirect.
- Home reads the existing profile, work experience, documents, saved jobs, and applications. It refreshes the personal overview when the screen regains focus. It shows a draft-resume action, otherwise profile completion when incomplete, useful shortcuts, and a location-search action when a preferred province exists.
- Kept the established rose accent, neutral surfaces, Plus Jakarta Sans, Lucide icons, and token system. Latest jobs now precede categories. No matching engine or unsupported employer interface was introduced.
- Company logos remain associated with their actual jobs. Account photos come only from existing auth metadata. Remote images use sized, cached images with initials or a profile-icon fallback. Existing bundled images were inspected; template artwork and the decorative blue glow are not used on Home.
- Fixed the shared icon wrapper's pre-existing web warning, which generated an error overlay over bottom navigation.

## Verification

Run `npm run test:navigation` for dependency-free routing and profile-contract tests using the existing TypeScript dependency.

Optional repeatable browser checks use Playwright and isolated API fixtures. They never sign into a real account or write production data:

```powershell
npm install --no-save --package-lock=false playwright
npx playwright install chromium
```

Start `npx expo start --web` in another terminal, then run:

```powershell
$env:CHROMIUM_PATH = "C:\path\to\chrome.exe"
node scripts/verify-ui.cjs
```

`APP_URL` overrides http://localhost:8081. `SCREENSHOT_DIR` overrides `work/ui-checks`. `CHROMIUM_PATH` points to an installed Chrome/Chromium executable; the script defaults to `/usr/bin/chromium` in the verification environment.

Checks performed and limitations are recorded in `docs/NAVIGATION-HOME-VERIFICATION.md`. No native device, real-account login, notification delivery, production database permissions, or native release signing is certified by fixture browser tests or JavaScript bundle export. The existing app has no separate employer navigation or mandatory onboarding gate; its profile/application eligibility logic remains intact.
