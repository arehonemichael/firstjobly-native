/* global __dirname */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
function load(file) {
  const source = fs.readFileSync(path.join(__dirname, '..', file), 'utf8');
  const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText;
  const module = { exports: {} };
  new Function('module', 'exports', js)(module, module.exports);
  return module.exports;
}
const { authDestination } = load('src/lib/auth-destination.ts');
const { computeProfileCompletion } = load('src/lib/profile-contract.ts');
test('normal login defaults to Home', () => {
  for (const value of [undefined, '', [], '/auth', '/unknown']) assert.equal(authDestination(value), '/');
});
test('existing destinations and job return links survive sign-in', () => {
  for (const value of ['/jobs/real-job-id', '/saved', '/applications', '/profile', '/cv-maker', '/z83', '/tools', '/graduateroom/new', '/graduateroom/verify', '/graduateroom/post-id', '/(tabs)/jobs?province=Gauteng', '/jobs?q=Developer']) assert.equal(authDestination(value), value);
  assert.equal(authDestination(['/jobs/job-id', '/profile']), '/jobs/job-id');
});
test('external URLs, malformed paths, and auth loops fall back to Home', () => {
  for (const value of ['https://example.com', '//example.com', '/\\example.com', '/jobs%2f%2fexample.com', '/auth?returnTo=/auth', '/jobs/../auth', '/ jobs', 'javascript:alert(1)']) assert.equal(authDestination(value), '/');
});
test('profile completion uses the established contract including false preferences', () => {
  assert.equal(computeProfileCompletion(null, [], []), 0);
  const profile = { first_name:'Test', last_name:'Candidate', email:'candidate@example.test', phone:'0123456789', province:'Gauteng', city:'Pretoria', date_of_birth:'2000-01-01', address:'Test address', about:'Test summary', highest_qualification:'Degree', institution:'Test institution', field_of_study:'Computing', year_completed:'2024', skills:['A','B','C'], languages:['English'], preferred_job_types:['permanent'], preferred_province:'Gauteng', preferred_city:'Pretoria', available_immediately:false, willing_to_relocate:false };
  assert.equal(computeProfileCompletion(profile, [{}], [{kind:'cv'}, {kind:'id'}, {kind:'certificate'}]), 100);
});
